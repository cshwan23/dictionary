import UIKit

//딕셔너리 초기화 하는 법
//mutable dictionary =var
var emptyDictionary = Dictionary<String,Int>()
//빈 딕셔너리가 됨
var emptyDictionary2 = [String:Int]()
// 비어있는지 확인
if emptyDictionary2.isEmpty {
    print("nothing in Dictionary")
}
emptyDictionary2["ant"] = 6
emptyDictionary2["snake"] = 0

print(emptyDictionary2)

//리터너리로 추가 하는 방법

var emptyDictionary3 = ["ant":6,"snake":0,"cheetah":4]
print(emptyDictionary3)
emptyDictionary3["human"] = 2
//순서가 없이 마음대로 추가된다
//값을 바꾸는 방법
emptyDictionary3["snake"] = 2
print(emptyDictionary3)

//하나씩 출력할때도
print(emptyDictionary3["cheetah"]!)

//immutable dictionary = let
let emptyDictionary4 = ["ant":6,"snake":0,"cheetah":4]
//emptyDictionary4["snake"] = 1 값을 넣거나 수정할 수 없다.
print(emptyDictionary4)

